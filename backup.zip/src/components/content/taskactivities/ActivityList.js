import React from 'react'

const ActivityList = () => {
  return (
    <div>ActivityList</div>
  )
}

export default ActivityList