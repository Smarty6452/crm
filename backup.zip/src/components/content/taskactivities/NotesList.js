import React from 'react'

const NotesList = () => {
  return (
    <div>NotesList</div>
  )
}

export default NotesList