import React from 'react'

const Deals = () => {
  return (
    <div>Deals</div>
  )
}

export default Deals