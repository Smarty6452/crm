import React from "react";
import Priority from "./MoreDetail/Priority";
import Steps from "./MoreDetail/Steps";
import Taskbar from "./MoreDetail/Taskbar";

const Detail = ({ cardData }) => {
  return (
    <div>
      {cardData ? (
        <div className="card-container bg-white rounded-lg overflow-hidden cursor-pointer">
          <div className="card-inner ">
            <Priority cardData={cardData} />
            <Steps />
            <Taskbar cardData={cardData} />
          </div>
        </div>
      ) : (
        <p>No data present</p>
      )}
    </div>
  );
};

export default Detail;
