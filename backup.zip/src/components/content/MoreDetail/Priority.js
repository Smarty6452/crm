import React from "react";
import { IoMdCall } from "react-icons/io";
import { AiOutlinePlus } from "react-icons/ai";
import { HiOutlineMail, HiOutlineChatAlt2, HiFolderOpen } from "react-icons/hi";
import { FaVideo } from "react-icons/fa";

const Priority = ({ cardData }) => {
  return (
    <>
      <div className="priority-wrap border-b-2 border-gray-300">

        <div className="flex px-10 pt-7">
          <div className="w-1/12 mt-2">
            <div className="card-img-wrap flex justify-center items-center ">
              <img
                className="card-image"
                src={cardData.image}
                alt={cardData.title}
              />
            </div>
          </div>
          <div className="w-full px-4  ">
            <h3 className="text-lg font-medium ">{cardData.title}</h3>
            <div className="mt-1">
              <button className="priority-btn mt"> <span ><AiOutlinePlus /></span>&nbsp;Set Priority</button>
            </div>

            <div className="last-activity py-3">
              Last Activity: 2 Jan, 5:45 pm
            </div>
          </div>
        </div>

        <div className="contact-btn-wrap px-10 pb-10 pt-3 flex">
          <button className="contact-btn flex items-center bg-6192FF rounded-md px-4 py-2">
            <IoMdCall className="mr-2 text-white" size={20} />
            <span className="text-white font-normal text-base">Call</span>
          </button>
          <button className="contact-btn flex items-center bg-6192FF rounded-md px-4 py-2">
            <HiOutlineMail className="mr-2 text-white" size={20} />
            <span className="text-white font-normal text-base">Email</span>
          </button>
          <button className="contact-btn flex items-center bg-6192FF rounded-md px-4 py-2">
            <HiOutlineChatAlt2 className="mr-2 text-white" size={20} />
            <span className="text-white font-normal text-base">SMS</span>
          </button>
          <button className="contact-btn flex items-center bg-6192FF rounded-md px-4 py-2">
            <FaVideo className="mr-2 text-white" size={20} />
            <span className="text-white font-normal text-base">Meeting</span>
          </button>
          <button className="contact-btn flex items-center bg-6192FF rounded-md px-4 py-2">
            <div className="text-white font-normal text-base">
            <AiOutlinePlus />
            </div>
            <div className="text-white font-normal text-base">
            &nbsp;Add Detail
            </div>
          
          </button>
          <button className="contact-btn flex items-center bg-6192FF rounded-md px-4 py-2">
            <HiFolderOpen className="mr-1 text-white" size={20} />
            <span className="text-white font-normal text-base">Task</span>
          </button>
          <button className="transfer-btn flex items-center bg-6192FF rounded-md px-4 py-2">
           
            <span className="text-white font-normal text-base">Transfer</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default Priority;
