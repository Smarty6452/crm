import React, { useState } from "react";
import TaskDetails from "../taskactivities/TaskDetails";
import TaskList from "../taskactivities/TaskList";
import ActivityList from "../taskactivities/ActivityList";
import NotesList from "../taskactivities/NotesList";
import Deals from "../taskactivities/Deals";
import Analytics from "../taskactivities/Analytics";

const Taskbar = ({ cardData }) => {
  const [activeTab, setActiveTab] = useState("tasks");

  const handleClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="flex flex-col h-full mx-14 mt-7">
      <div className="flex justify-between items-center  text-black py-4 px-6 ">
      
        <div className="flex">
          <button
            onClick={() => handleClick("details")}
            className={`mr-8  ${
              activeTab === "details" ? "bg-blue-500 text-white" : ""
            } taskbar-btn`}
          >
            Details
          </button>
          <button
            onClick={() => handleClick("tasks")}
            className={`mr-8 ${
              activeTab === "tasks" ? "bg-blue-500" : ""
            } taskbar-btn`}
          >
            Activities
          </button>
          <button
            onClick={() => handleClick("activities")}
            className={`mr-8 ${
              activeTab === "activities" ? "bg-blue-500" : ""
            } taskbar-btn`}
          >
            Tasks
          </button>
          <button
            onClick={() => handleClick("notes")}
            className={`mr-8 ${activeTab === "notes" ? "bg-blue-500" : ""}  taskbar-btn`}
          >
            Notes
          </button>
          <button
            onClick={() => handleClick("deals")}
            className={`mr-8 ${activeTab === "deals" ? "bg-blue-500" : ""} taskbar-btn`}
          >
            Deals
          </button>
          <button
            onClick={() => handleClick("analytics")}
            className={`mr-8 ${activeTab === "analytics" ? "bg-blue-500" : ""} taskbar-btn`}
          >
           Analytics
          </button>
        </div>
      </div>
      <div className="flex-1 p-4">
        {activeTab === "details" && <TaskDetails cardData={cardData} />}
        {activeTab === "tasks" && <TaskList />}
        {activeTab === "activities" && <ActivityList />}
        {activeTab === "notes" && <NotesList />}
        {activeTab === "deals" && <Deals />}
        {activeTab === "analytics" && <Analytics />}
      </div>
    </div>
  );
};

export default Taskbar;
