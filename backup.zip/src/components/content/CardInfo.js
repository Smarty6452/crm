import React, {useState, useEffect} from "react";


// const { Meta } = AntCard;

const CardInfo = ({onCardSelect}) => {
  // Function to get button style based on text
  const [selectedCard, setSelectedCard] = useState(0); // state to hold selected card data
  const getButtonStyle = (text) => {
    let buttonStyle = {
      backgroundColor: "#000000", // Default color
      color: "#FFFFFF", // Default text color
    };
    if (text === "Cold Lead") {
      buttonStyle.backgroundColor = "#C7FDBE";
      buttonStyle.color = "#2e8a2c";
    } else if (text === "Hot Lead") {
      buttonStyle.backgroundColor = "#FDC1BE";
      buttonStyle.color = "#8A3D2C";
    } else if (text === "Warm Lead") {
      buttonStyle.backgroundColor = "#FDD8BE";
      buttonStyle.color = "#8A4E2C";
    }
    return buttonStyle;
  };

 // Dummy data for cards
 const cardData = [
  {
    id: 1,
    title: "Harish Verma",
    description: "Meeting is scheduled for 5th july at 3:00 pm.",
    image:
      "https://ik.imagekit.io/aq3ybtarw/CRM/irene-strong-v2aKnjMbP_k-unsplash-min.jpg?updatedAt=1680421088764",
    buttonText: "Cold Lead",
  },
  {
    id: 2,
    title: "Mohan Verma",
    description: "Call is scheduled for 5th july at 3:00 pm",
    image:
      "https://ik.imagekit.io/aq3ybtarw/CRM/irene-strong-v2aKnjMbP_k-unsplash-min.jpg?updatedAt=1680421088764",
    buttonText: "Hot Lead",
  },
  {
    id: 3,
    title: "Disha Verma",
    description: "Follow up is pending.",
    image:
      "https://ik.imagekit.io/aq3ybtarw/CRM/irene-strong-v2aKnjMbP_k-unsplash-min.jpg?updatedAt=1680421088764",
    buttonText: "Warm Lead",
  },
  {
    id: 4,
    title: "Madhera Verma",
    description: "Follow up is pending",
    image:
      "https://ik.imagekit.io/aq3ybtarw/CRM/irene-strong-v2aKnjMbP_k-unsplash-min.jpg?updatedAt=1680421088764",
    buttonText: "Cold Lead",
  },
  {
    id: 5,
    title: "Hari Verma",
    description: "Meeting is scheduled for 5th july at 3:00 pm.",
    image:
      "https://ik.imagekit.io/aq3ybtarw/CRM/irene-strong-v2aKnjMbP_k-unsplash-min.jpg?updatedAt=1680421088764",
    buttonText: "Hot Lead",
  },
];


 // Set the initial selectedCard to the first object in the cardData array
 useEffect(() => {
  setSelectedCard(cardData[0]);
}, []);

const handleCardClick = (card) => {
  setSelectedCard(card);
  onCardSelect(card);
};

  return (
    <div className="flex flex-col space-y-8">
    {cardData.map((card) => (
      <div className="card-container bg-white rounded-lg shadow-md overflow-hidden cursor-pointer"   key={card.id}
      onClick={() => handleCardClick(card)}>
        <div className="flex p-4 ">
          <div className="w-1/5 mt-2">
            <div className="card-img-wrap ">
              <img className="card-image" src={card.image} alt={card.title} />
            </div>
          </div>
          <div className="w-full px-4  ">
            <h3 className="text-lg font-medium ">{card.title}</h3>
            <p className="text-gray-600 text-base card-description">{card.description}</p>
            <div className="mt-4">
              <button
                style={getButtonStyle(card.buttonText)}
                className="card-button"
              >
                {card.buttonText}
              </button>
            </div>
          </div>
        </div>
      </div>
    ))}
  </div>
  );
};

export default CardInfo;
