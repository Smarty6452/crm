import React, {useState} from "react";
import { Row, Col } from "antd";
import Cards from "../components/content/CardInfo";
import Detail from "../components/content/Detail";

const Dashboard = () => {
  const [selectedCard, setSelectedCard] = useState(null);

  const handleCardSelection = (cardData) => {
    setSelectedCard(cardData);
  };
  return (
    <div className="content">
  <Row gutter={[16, 16]}  >
    <Col xs={24} md={7}>
      <div className="left-content-wrap">
        <Cards onCardSelect={handleCardSelection} />
      </div>
    </Col>
    <Col xs={24} md={16}>
    <div className="right-content-wrap">
        {selectedCard ? <Detail cardData={selectedCard} /> : <p>Please select a card</p>}
      </div>
    </Col>
  </Row>
</div>

  );
};

export default Dashboard;
